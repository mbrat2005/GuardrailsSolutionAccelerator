function Test-AllowedLocation {
    param (
        [array] $AssignedLocations,
        [array] $AllowedLocations
    )
    $IsCompliant = $true
    foreach ($AssignedLocation in $AssignedLocations) {
        if ( $AssignedLocation -notin $AllowedLocations) {
            $IsCompliant = $false
        }
    }
    
    return $IsCompliant 
}

function Verify-AllowedLocationPolicy {
    param (
        [switch] $DebugData,
        [string] $ControlName,
        [string] $ItemName,
        [string] $PolicyID, 
        [string] $WorkSpaceID,
        [string] $workspaceKey,
        [string] $LogType,
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory=$true)]
        [string]
        $CBSSubscriptionName
    )

    #$PolicyID = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

    [System.Object] $RootMG = $null
    [string] $PolicyID = $policyID
    [PSCustomObject] $MGList = New-Object System.Collections.ArrayList
    [PSCustomObject] $MGItems = New-Object System.Collections.ArrayList
    [PSCustomObject] $SubscriptionList = New-Object System.Collections.ArrayList
    [PSCustomObject] $CompliantList = New-Object System.Collections.ArrayList
    [PSCustomObject] $NonCompliantList = New-Object System.Collections.ArrayList
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $AllowedLocations = @("canada" , "canadaeast" , "canadacentral")

    try {
        $managementGroups = Get-AzManagementGroup -ErrorAction Stop
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of the Az.Resources module; returned error message: $_")  | Out-Null
        throw "Error: Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of the Az.Resources module; returned error message: $_"
    }
    
    foreach ($mg in $managementGroups) {
        $MG = Get-AzManagementGroup -GroupName $mg.Name -Expand -Recurse
        $MGItems.Add($MG) | Out-Null
        if ($null -eq $MG.ParentId) {
            $RootMG = $MG
        }
    }
    foreach ($items in $MGItems) {
        foreach ($Children in $items.Children ) {
            foreach ($c in $Children) {
                if ($c.Type -eq "/subscriptions" -and (-not $SubscriptionList.Contains($c) -and $c.DisplayName -ne $CBSSubscriptionName)) {
                    [string]$type = "subscription"
                    $SubscriptionList.Add($c)  | Out-Null

                    try {
                        $AssignedPolicyList = Get-AzPolicyAssignment -scope $c.Id -PolicyDefinitionId $PolicyID -ErrorAction Stop
                    }
                    catch {
                        $Errorlist.Add("Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($c.id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_" )
                        Write-Error "Error: Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($c.id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_"                
                    }
                    $AssignedPolicyLocation = $AssignedPolicyList.Properties.Parameters.listOfAllowedLocations.value

                    If ($null -eq $AssignedPolicyList) {
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.policyNotAssigned -f $type) | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ComplianceStatus -Value $false | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        $NonCompliantList.add($c) | Out-Null
                    }
                    elseif (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))   ) {
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $false | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        if (-not (Test-AllowedLocation -AssignedLocations $AssignedPolicyLocation -AllowedLocations $AllowedLocations)  ) {
                            $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.excludedFromScope -f $type + $msgTable.notAllowedLocation) | out-null
                        }
                        else {
                            $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.excludedFromScope -f $type) | out-null
                        }
                        $NonCompliantList.add($c)  | Out-Null 
                    }
                    else {
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name Comments -Value $msgTable.isCompliant | out-null
                        $c | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $true | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        $CompliantList.add($c)  | Out-Null
                    }
                }
                elseif ($c.Type -like "*managementGroups*" -and (-not $MGList.Contains($c)) ) {
                    [string]$type = "Management Groups"
                    $MGList.Add($c) | Out-Null

                    try {
                        $AssignedPolicyList = Get-AzPolicyAssignment -scope $c.Id -PolicyDefinitionId $PolicyID -ErrorAction Stop
                    }
                    catch {
                        $Errorlist.Add("Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($c.id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_")  | Out-Null
                        Write-Error "Error: Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($c.id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_"                
                    }

                    If ($null -eq $AssignedPolicyList) {
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.policyNotAssigned -f $type) | out-null
                        $c | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $false | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        $NonCompliantList.add($c) | Out-Null
                    }
                    elseif (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))) {
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        $c | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $false | out-null
                        if (-not (Test-AllowedLocation -AssignedLocations $AssignedPolicyLocation -AllowedLocations $AllowedLocations)  ) {
                            $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.excludedFromScope -f $type + $msgTable.notAllowedLocation) | out-null
                        }
                        else {
                            $c | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.excludedFromScope -f $type) | out-null
                        }
                        $NonCompliantList.add($c)   | Out-Null
                    }
                    else {       
                        $c | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
                        $c | Add-Member -MemberType NoteProperty -Name Comments -Value $msgTable.isCompliant | out-null
                        $c | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $true | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
                        $c | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
                        $CompliantList.add($c)  | Out-Null
                    }
                }
            }                
        }
    }


    try {
        $AssignedPolicyList = Get-AzPolicyAssignment -scope $RootMG.Id -PolicyDefinitionId $PolicyID -ErrorAction Stop
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($RootMG.Id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_")
        Write-Error "Error: Failed to execute the 'Get-AzPolicyAssignment' command for scope '$($RootMG.Id)'--verify your permissions and the installion of the Az.Resources module; returned error message: $_"                
    }
    If ($null -eq $AssignedPolicyList) {
        $RootMG | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name Comments -Value $msgTable.policyNotAssignedRootMG | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $false | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
        $NonCompliantList.add($RootMG) | Out-Null
    }
    elseif (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))) {
        $RootMG | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $false | out-null
        if (-not (Test-AllowedLocation -AssignedLocations $AssignedPolicyLocation -AllowedLocations $AllowedLocations)  ) {
            $RootMG | Add-Member -MemberType NoteProperty -Name Comments -Value $($msgTable.rootMGExcluded + $msgTable.notAllowedLocation) | out-null
        }
        else {
            $RootMG | Add-Member -MemberType NoteProperty -Name Comments -Value $msgTable.rootMGExcluded | out-null
        }
        $NonCompliantList.add($RootMG)   | Out-Null
    }
    else {       
        $RootMG | Add-Member -MemberType NoteProperty -Name Comments -Value $msgTable.isCompliant | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name "ComplianceStatus" -Value $true | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ControlName -Value $ControlName -Force | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ItemName -Value $ItemName -Force | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name itsgcode -Value $itsgcode | out-null
        $RootMG | Add-Member -MemberType NoteProperty -Name ReportTime -Value $ReportTime -Force | out-null
        $CompliantList.add($RootMG)  | Out-Null
    }
    $finalList = $CompliantList + $NonCompliantList
    <#
    if ($CompliantList.Count -gt 0) {
        $JsonObject = $CompliantList | convertTo-Json
        if ($DebugData) {
            "Sending Compliant data."
            "Id: $WorkSpaceID"
            "Key: $workspaceKey"
            "Body: $JsonObject"
        }
        Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
            -sharedkey $workspaceKey `
            -body $JsonObject `
            -logType $LogType `
            -TimeStampField Get-Date
    }
    if ($NonCompliantList.Count -gt 0) {
        $JsonObject = $NonCompliantList | convertTo-Json  
        if ($DebugData) {
            "Sending Non-Compliant data."
            "Id: $WorkSpaceID"
            "Key: $workspaceKey"
            "Body: $JsonObject"
        }
        Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
            -sharedkey $workspaceKey `
            -body $JsonObject `
            -logType $LogType `
            -TimeStampField Get-Date
    }
    #>
    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $finalList 
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput  
}

